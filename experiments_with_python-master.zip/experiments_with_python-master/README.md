# experiments_with_python


A collection of Python projects

1. Machine Learning [[ipynb](./chp01/)]  
2. Computer Vision  [[ipynb](./chp02/)]  
3. Optimization     [[ipynb](./chp03/)]  
4. Finance          [[ipynb](./chp04/)]  

### Dependencies

Python 2.7  
sklearn 0.18  
PyMC 3.1  
TensorFlow 1.0.1  

